﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.customizationPanel = New System.Windows.Forms.Panel()
        Me.customizationPanel1 = New System.Windows.Forms.Panel()
        Me.title = New System.Windows.Forms.Label()
        Me.about = New System.Windows.Forms.Button()
        Me.simpleclean = New System.Windows.Forms.Button()
        Me.deepclean = New System.Windows.Forms.Button()
        Me.cleanprogress = New System.Windows.Forms.ProgressBar()
        Me.simpleprogressTimer = New System.Windows.Forms.Timer(Me.components)
        Me.deepprogressTimer = New System.Windows.Forms.Timer(Me.components)
        Me.secondPlane = New System.Windows.Forms.Timer(Me.components)
        Me.isVisible = New System.Windows.Forms.Timer(Me.components)
        Me.others = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'customizationPanel
        '
        Me.customizationPanel.BackColor = System.Drawing.Color.RoyalBlue
        Me.customizationPanel.Location = New System.Drawing.Point(0, 47)
        Me.customizationPanel.Name = "customizationPanel"
        Me.customizationPanel.Size = New System.Drawing.Size(55, 330)
        Me.customizationPanel.TabIndex = 0
        '
        'customizationPanel1
        '
        Me.customizationPanel1.BackColor = System.Drawing.Color.RoyalBlue
        Me.customizationPanel1.Location = New System.Drawing.Point(0, 0)
        Me.customizationPanel1.Name = "customizationPanel1"
        Me.customizationPanel1.Size = New System.Drawing.Size(615, 51)
        Me.customizationPanel1.TabIndex = 1
        '
        'title
        '
        Me.title.AutoSize = True
        Me.title.Font = New System.Drawing.Font("Arial", 23.0!)
        Me.title.ForeColor = System.Drawing.SystemColors.Control
        Me.title.Location = New System.Drawing.Point(242, 65)
        Me.title.Name = "title"
        Me.title.Size = New System.Drawing.Size(156, 35)
        Me.title.TabIndex = 2
        Me.title.Text = "JSCleaner"
        '
        'about
        '
        Me.about.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.about.Location = New System.Drawing.Point(527, 343)
        Me.about.Name = "about"
        Me.about.Size = New System.Drawing.Size(88, 35)
        Me.about.TabIndex = 3
        Me.about.Text = "Sobre"
        Me.about.UseVisualStyleBackColor = True
        '
        'simpleclean
        '
        Me.simpleclean.Font = New System.Drawing.Font("Arial", 15.0!)
        Me.simpleclean.Location = New System.Drawing.Point(236, 134)
        Me.simpleclean.Name = "simpleclean"
        Me.simpleclean.Size = New System.Drawing.Size(175, 65)
        Me.simpleclean.TabIndex = 4
        Me.simpleclean.Text = "Limpeza Simples"
        Me.simpleclean.UseVisualStyleBackColor = True
        '
        'deepclean
        '
        Me.deepclean.Font = New System.Drawing.Font("Arial", 14.0!)
        Me.deepclean.Location = New System.Drawing.Point(236, 205)
        Me.deepclean.Name = "deepclean"
        Me.deepclean.Size = New System.Drawing.Size(175, 65)
        Me.deepclean.TabIndex = 5
        Me.deepclean.Text = "Limpeza Profunda"
        Me.deepclean.UseVisualStyleBackColor = True
        '
        'cleanprogress
        '
        Me.cleanprogress.Enabled = False
        Me.cleanprogress.Location = New System.Drawing.Point(236, 347)
        Me.cleanprogress.Name = "cleanprogress"
        Me.cleanprogress.Size = New System.Drawing.Size(175, 23)
        Me.cleanprogress.TabIndex = 6
        Me.cleanprogress.Visible = False
        '
        'simpleprogressTimer
        '
        Me.simpleprogressTimer.Interval = 2000
        '
        'deepprogressTimer
        '
        Me.deepprogressTimer.Interval = 4000
        '
        'secondPlane
        '
        Me.secondPlane.Interval = 180000
        '
        'isVisible
        '
        Me.isVisible.Interval = 1
        '
        'others
        '
        Me.others.Font = New System.Drawing.Font("Arial", 14.0!)
        Me.others.Location = New System.Drawing.Point(236, 276)
        Me.others.Name = "others"
        Me.others.Size = New System.Drawing.Size(175, 65)
        Me.others.TabIndex = 7
        Me.others.Text = "Outros"
        Me.others.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(614, 377)
        Me.Controls.Add(Me.others)
        Me.Controls.Add(Me.cleanprogress)
        Me.Controls.Add(Me.deepclean)
        Me.Controls.Add(Me.simpleclean)
        Me.Controls.Add(Me.about)
        Me.Controls.Add(Me.title)
        Me.Controls.Add(Me.customizationPanel1)
        Me.Controls.Add(Me.customizationPanel)
        Me.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JSCleaner"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents customizationPanel As System.Windows.Forms.Panel
    Friend WithEvents customizationPanel1 As System.Windows.Forms.Panel
    Friend WithEvents title As System.Windows.Forms.Label
    Friend WithEvents about As System.Windows.Forms.Button
    Friend WithEvents simpleclean As System.Windows.Forms.Button
    Friend WithEvents deepclean As System.Windows.Forms.Button
    Friend WithEvents cleanprogress As System.Windows.Forms.ProgressBar
    Friend WithEvents simpleprogressTimer As System.Windows.Forms.Timer
    Friend WithEvents deepprogressTimer As System.Windows.Forms.Timer
    Friend WithEvents secondPlane As System.Windows.Forms.Timer
    Friend WithEvents isVisible As System.Windows.Forms.Timer
    Friend WithEvents others As System.Windows.Forms.Button

End Class
