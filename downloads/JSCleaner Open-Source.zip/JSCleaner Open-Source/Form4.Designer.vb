﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.folderbrowser = New System.Windows.Forms.FolderBrowserDialog()
        Me.selectfolder = New System.Windows.Forms.Button()
        Me.cleanfolder = New System.Windows.Forms.Button()
        Me.folderaddress = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'selectfolder
        '
        Me.selectfolder.Font = New System.Drawing.Font("Arial", 13.0!)
        Me.selectfolder.Location = New System.Drawing.Point(91, 12)
        Me.selectfolder.Name = "selectfolder"
        Me.selectfolder.Size = New System.Drawing.Size(175, 70)
        Me.selectfolder.TabIndex = 7
        Me.selectfolder.Text = "Selecionar Pasta"
        Me.selectfolder.UseVisualStyleBackColor = True
        '
        'cleanfolder
        '
        Me.cleanfolder.Location = New System.Drawing.Point(91, 154)
        Me.cleanfolder.Name = "cleanfolder"
        Me.cleanfolder.Size = New System.Drawing.Size(175, 36)
        Me.cleanfolder.TabIndex = 8
        Me.cleanfolder.Text = "Limpar"
        Me.cleanfolder.UseVisualStyleBackColor = True
        '
        'folderaddress
        '
        Me.folderaddress.Enabled = False
        Me.folderaddress.Location = New System.Drawing.Point(12, 106)
        Me.folderaddress.Name = "folderaddress"
        Me.folderaddress.Size = New System.Drawing.Size(330, 26)
        Me.folderaddress.TabIndex = 9
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(354, 202)
        Me.Controls.Add(Me.folderaddress)
        Me.Controls.Add(Me.cleanfolder)
        Me.Controls.Add(Me.selectfolder)
        Me.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "JSCleaner | Limpeza Específica"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents folderbrowser As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents selectfolder As System.Windows.Forms.Button
    Friend WithEvents cleanfolder As System.Windows.Forms.Button
    Friend WithEvents folderaddress As System.Windows.Forms.TextBox
End Class
