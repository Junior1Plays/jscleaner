﻿Imports System.IO

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cleanprogress.Enabled = False
        simpleprogressTimer.Stop()
        deepprogressTimer.Stop()
    End Sub

    Private Sub simpleclean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles simpleclean.Click
        simpleprogressTimer.Start()
        simpleclean.Enabled = False
        deepclean.Enabled = False
        cleanprogress.Visible = True
    End Sub

    Private Sub deepclean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deepclean.Click
        deepprogressTimer.Start()
        simpleclean.Enabled = False
        deepclean.Enabled = False
        cleanprogress.Visible = True
    End Sub

    Private Sub about_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles about.Click
        MsgBox("JSCleaner é um programa código-aberto, feito para fazer um limpeza simples e profunda gratuitamente!", MsgBoxStyle.Information, "JSCleaner")
    End Sub

    Private Sub simpleprogressTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles simpleprogressTimer.Tick
        If cleanprogress.Value = 90 Then
            cleanprogress.Value = (cleanprogress.Value + 10)
            simpleprogressTimer.Stop()
        Else
            cleanprogress.Value = (cleanprogress.Value + 30)
        End If
        If cleanprogress.Value = 100 Then
            'Definir Pasta
            Dim dir1 = "C:\Windows\Temp"
            'Limpar Pasta
            For Each x In Directory.GetFiles(dir1)
                Try
                    IO.File.Delete(x)

                Catch ex As Exception

                End Try
            Next
            'Limpeza Concluida
            cleanprogress.Value = 0
            simpleclean.Enabled = True
            deepclean.Enabled = True
            cleanprogress.Enabled = False
            cleanprogress.Visible = False
            MsgBox("Limpeza Simples Concluida com Sucesso!", MsgBoxStyle.Information, "JSCleaner")

        End If
    End Sub

    Private Sub deepprogressTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deepprogressTimer.Tick
        cleanprogress.Value = (cleanprogress.Value + 10)
        If cleanprogress.Value = 100 Then
            'Definir Pastas
            Dim dir1 = "C:\Windows\Temp"
            Dim dir2 = "C:\Users\" + SystemInformation.UserName + "\AppData\Local\Temp"
            Dim dir3 = "C:\Windows\Prefetch"
            'Limpar Pastas
            For Each x In Directory.GetFiles(dir1)
                Try
                    IO.File.Delete(x)

                Catch ex As Exception

                End Try
            Next
            For Each x In Directory.GetFiles(dir2)
                Try
                    IO.File.Delete(x)

                Catch ex As Exception

                End Try
            Next
            For Each x In Directory.GetFiles(dir3)
                Try
                    IO.File.Delete(x)

                Catch ex As Exception

                End Try
            Next
            'Limpeza Concluida
            simpleclean.Enabled = True
            deepclean.Enabled = True
            cleanprogress.Value = 0
            cleanprogress.Enabled = False
            cleanprogress.Visible = False
            MsgBox("Limpeza Profunda Concluida com Sucesso!", MsgBoxStyle.Information, "JSCleaner")
            deepprogressTimer.Stop()
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim msgboxres As MsgBoxResult
        msgboxres = MsgBox("Você quer deixar JSCleaner em segundo plano limpando o sistema a cada 3 minutos?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "JSCleaner")
        If msgboxres = vbYes Then
            e.Cancel = True
            Me.Visible = False
            secondPlane.Start()
            isVisible.Start()
            Form2.Show()
        End If
    End Sub

    Private Sub secondPlane_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles secondPlane.Tick
        'Definir Pastas
        Dim dir1 = "C:\Windows\Temp"
        Dim dir2 = "C:\Users\" + SystemInformation.UserName + "\AppData\Local\Temp"
        Dim dir3 = "C:\Windows\Prefetch"
        'Limpar Pastas
        For Each x In Directory.GetFiles(dir1)
            Try
                IO.File.Delete(x)

            Catch ex As Exception

            End Try
        Next
        For Each x In Directory.GetFiles(dir2)
            Try
                IO.File.Delete(x)

            Catch ex As Exception

            End Try
        Next
        For Each x In Directory.GetFiles(dir3)
            Try
                IO.File.Delete(x)

            Catch ex As Exception

            End Try
        Next
        secondPlane.Stop()
        secondPlane.Start()
    End Sub

    Private Sub isVisible_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles isVisible.Tick
        If Me.Visible = True Then
            secondPlane.Stop()
            isVisible.Stop()
            MsgBox("JSCleaner ficou visível, e sua limpeza automática foi desativada.", MsgBoxStyle.OkOnly, "JSCleaner")
        End If
    End Sub
End Class