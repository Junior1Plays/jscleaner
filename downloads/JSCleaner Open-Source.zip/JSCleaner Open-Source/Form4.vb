﻿Imports System.IO

Public Class Form4

    Private Sub selectfolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles selectfolder.Click
        folderbrowser.ShowDialog()
        If folderbrowser.SelectedPath = "C:\" Then
            MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
            cleanfolder.Enabled = False
        Else
            If folderbrowser.SelectedPath = "C:\Windows" Then
                MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
                cleanfolder.Enabled = False
            Else
                If folderbrowser.SelectedPath = "C:\Windows\System32" Then
                    MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
                    cleanfolder.Enabled = False
                Else
                    If folderbrowser.SelectedPath = "C:\Windows\system32" Then
                        MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
                        cleanfolder.Enabled = False
                    Else
                        If folderbrowser.SelectedPath = "C:\Users\" + SystemInformation.UserName + "\Desktop" Then
                            MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
                            cleanfolder.Enabled = False
                        Else
                            If folderbrowser.SelectedPath = "C:\Users\" + SystemInformation.UserName Then
                                MsgBox("Essa é uma pasta importante do sistema, e não pode ser limpa!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "JSCleaner")
                                cleanfolder.Enabled = False
                            Else
                                cleanfolder.Enabled = True
                            End If
                        End If
                    End If
                End If
            End If
        End If
        folderaddress.Text = folderbrowser.SelectedPath()
    End Sub

    Private Sub cleanfolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cleanfolder.Click
        'Limpar Pasta
        For Each x In Directory.GetFiles(folderbrowser.SelectedPath())
            Try
                IO.File.Delete(x)

            Catch ex As Exception

            End Try
        Next
        'Limpeza Concluida
        MsgBox("Limpeza Específica Concluida com Sucesso!", MsgBoxStyle.Information, "JSCleaner")
    End Sub
End Class