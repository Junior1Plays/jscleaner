﻿Public Class Form3

    Private Sub specifyclean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles specifyclean.Click
        Form4.Show()
    End Sub
End Class